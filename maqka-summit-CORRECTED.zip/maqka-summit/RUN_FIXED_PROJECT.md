# Maqka Summit — repaired project

## What was repaired
- Added SQLite migrations so an existing database receives columns introduced by newer versions.
- Fixed development login when `JWT_SECRET` is not present.
- Updated JWT middleware to use the same development fallback.
- Improved backend error messages in development.
- Kept the existing React frontend, customer dashboard, admin dashboard, booking system and assets.
- Kept the Vite `/api` proxy for local/Codespaces development.

## Run in GitHub Codespaces

Terminal 1:
```bash
cd backend
npm install
npm run seed
npm start
```

Terminal 2:
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```

Open the forwarded **5173** port.

## Production
Set these environment variables on the backend:
- `JWT_SECRET` = a long random secret
- `FRONTEND_URL` = your frontend URL
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` if you use the seed command

On the frontend set:
- `VITE_API_BASE_URL=https://YOUR-BACKEND-DOMAIN/api`

Do not use the development JWT fallback in production.
